create view vwCitas as
select `wp`.`post_title`   AS `post_title`,
       `wp`.`ID`           AS `ID`,
       `wp`.`post_excerpt` AS `post_excerpt`,
       `wp`.`post_name`    AS `post_name`,
       `wp`.`post_content` AS `post_content`
from `biblic26_db`.`wp_posts` `wp`
where ((`wp`.`post_type` = 'citas-sud') and (`wp`.`post_status` = 'publish'))
order by `wp`.`post_title`;

