create view vwCapitulos as
select `capitulos`.`ID`         AS `ID`,
       `capitulos`.`post_title` AS `post_title`,
       `capitulos`.`post_name`  AS `post_name`,
       `capitulos`.`menu_order` AS `menu_order`
from `biblic26_db`.`wp_posts` `capitulos`
where ((`capitulos`.`post_type` = 'capitulo-escrituras') and (`capitulos`.`post_status` = 'publish'))
order by `capitulos`.`menu_order`;

