create view vwGlosarioXCapitulo as
select 'Glosario' AS `sitio`, `wt`.`name` AS `name`, `p`.`post_title` AS `post_title`, `p`.`guid` AS `guid`
from (((`biblic26_db`.`wp_9_terms` `wt` join `biblic26_db`.`wp_9_term_taxonomy` `wtt` on ((`wt`.`term_id` = `wtt`.`term_id`))) join `biblic26_db`.`wp_9_term_relationships` `wtr` on ((`wtt`.`term_taxonomy_id` = `wtr`.`term_taxonomy_id`)))
         join `biblic26_db`.`wp_9_posts` `p` on ((`wtr`.`object_id` = `p`.`ID`)))
where ((`p`.`post_type` = 'post') and (`p`.`post_status` = 'publish') and (`wtt`.`taxonomy` = 'cptcapitulo'))
order by `p`.`post_title`;

