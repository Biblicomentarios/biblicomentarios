create view vwCitasSinAsignar as
select `wp`.`post_title` AS `post_title`, `wp`.`ID` AS `ID`
from (`biblic26_db`.`wp_posts` `wp`
         left join `biblic26_db`.`wp_toolset_associations` `wta` on ((`wp`.`ID` = `wta`.`parent_id`)))
where ((`wp`.`post_type` = 'citas-sud') and isnull(`wta`.`parent_id`))
order by `wp`.`post_title`;

