create view vwCapitulosId as
select `wp`.`ID` AS `id`, `wp`.`post_title` AS `post_title`
from `biblic26_db`.`wp_posts` `wp`
where (`wp`.`post_type` = 'capitulo-escrituras')
order by `wp`.`post_title`;

