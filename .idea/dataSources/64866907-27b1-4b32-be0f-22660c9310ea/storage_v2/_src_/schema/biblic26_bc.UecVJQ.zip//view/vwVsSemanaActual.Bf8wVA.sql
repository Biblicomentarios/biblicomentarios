create view vwVsSemanaActual as
select `v`.`IdSemanas`  AS `IdSemanas`,
       `v`.`Imagen`     AS `Imagen`,
       `v`.`Titulo`     AS `Titulo`,
       `v`.`Asignacion` AS `Asignacion`,
       `v`.`URLOficial` AS `URLOficial`,
       `v`.`Reseña`     AS `Resenia`
from `biblic26_bc`.`vssemanas` `v`
where date_format(current_timestamp(), '%Y/%m/%d') between `v`.`FInicio` and `v`.`Ffinal`;

